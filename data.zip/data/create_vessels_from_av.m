function create_vessels_from_av()
% Arteries are labelled in red; veins are labelled in blue; 
% the overlapping of arteries and veins are labelled in green; 
% the vessels which are uncertain are labelled in white. 

path_im_train = 'training/images/';
path_im_test = 'test/images/';

path_av_train = 'training/a_v/';
path_av_test = 'test/a_v/';

path_vessels_train = 'training/vessels/';
path_vessels_test = 'test/vessels/';

path_arteries_train = 'training/arteries/';
path_veins_train = 'training/veins/';


path_arteries_test = 'test/arteries/';
path_veins_test = 'test/veins/';


mkdir(path_vessels_train);
mkdir(path_vessels_test);
mkdir(path_arteries_train);
mkdir(path_veins_train);
mkdir(path_arteries_test);
mkdir(path_veins_test);







im_list=dir(path_av_train);
im_list = im_list(3:end);

num_ims = length(im_list);

for i=1:num_ims
   im_name = im_list(i).name;
   im_name_full = [path_im_train, im_name(1:end-4), '.tif'];
   im_name_out =  [path_im_train, im_name(1:end-4), '.png'];
   image = imread(im_name_full);
   imwrite(image, im_name_out);

%    im_name = im_list(i).name;
%    a_v = imread([path_av_train, im_name]); 
%    figure(1), imshow(a_v)
%    
%      
%    I_r = a_v(:,:,1);
%    I_g = a_v(:,:,2);
%    I_b = a_v(:,:,3);
%    
%      
%    veins = zeros(size(I_b));
%    veins(I_b>0 & I_r <255) = 1; % add veins; do not add white pixels
%    veins(I_g == 255 & I_r <255) = 1; % add back yellow pixels as veins
%    figure(2), imshow(veins)
%    
%    
%    arteries = zeros(size(I_g));
%    arteries(I_r>0 & I_b < 255) = 1; % add arteries; do not add white pixels
%    figure(3), imshow(arteries)
%    
%    vessels = arteries+veins;
%    figure(4), imshow(vessels)
%    
%    arteries_name_out = [path_arteries_train, im_name];
%    imwrite(arteries, arteries_name_out);
%    
%    veins_name_out = [path_veins_train, im_name];
%    imwrite(veins, veins_name_out);
%    
%    veseels_name_out = [path_vessels_train, im_name];
%    imwrite(vessels, veseels_name_out);   
   
   disp(i)
end



im_list=dir(path_im_test);
im_list = im_list(3:end);

num_ims = length(im_list);

for i=1:num_ims
   im_name = im_list(i).name;
   im_name_full = [path_im_test, im_name(1:end-4), '.tif'];
   im_name_out =  [path_im_test, im_name(1:end-4), '.png'];
   image = imread(im_name_full);
   imwrite(image, im_name_out);

%    im_name = im_list(i).name;
%    a_v = imread([path_av_test, im_name]); 
%    figure(1), imshow(a_v)
%    
%      
%    I_r = a_v(:,:,1);
%    I_g = a_v(:,:,2);
%    I_b = a_v(:,:,3);
%    
%      
%    veins = zeros(size(I_b));
%    veins(I_b>0 & I_r <255) = 1; % add veins; do not add white pixels
%    veins(I_g == 255 & I_r <255) = 1; % add back yellow pixels as veins
%    figure(2), imshow(veins)
%    
%    
%    arteries = zeros(size(I_g));
%    arteries(I_r>0 & I_b < 255) = 1; % add arteries; do not add white pixels
%    figure(3), imshow(arteries)
%    
%    vessels = arteries+veins;
%    figure(4), imshow(vessels)
%    
%    arteries_name_out = [path_arteries_test, im_name];
%    imwrite(arteries, arteries_name_out);
%    
%    veins_name_out = [path_veins_test, im_name];
%    imwrite(veins, veins_name_out);
%    
%    veseels_name_out = [path_vessels_test, im_name];
%    imwrite(vessels, veseels_name_out);   
   
   disp(i)
end

end